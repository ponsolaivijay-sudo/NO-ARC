
  # Enhance UI Design

  This is a code bundle for Enhance UI Design. The original project is available at https://www.figma.com/design/Ob88ErTbpDsA0ieZHytxgA/Enhance-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  